def binary(num):
    n = ""
    while(num>0):
        temp = num%2
        num = num//2
        n = n + str(temp)
    return n

def Hamming(x,y):
    x = binary(x)
    y = binary(y)
    count = 0
    if len(x) > len(y): 
        for i in range(len(y),len(x)):
            y = y + "0"
    if len(y) > len(x):
        for i in range(len(x),len(y)):
            x = x + "0"
    for i in range(0,len(x)):
        if x[i] != y[i]:
            count = count + 1
        else:
            pass
    return count
print(Hamming(25,30))
print(Hamming(1,4))
print(Hamming(25,30))
print(Hamming(100,250))
print(Hamming(1,30))
print(Hamming(0,255))