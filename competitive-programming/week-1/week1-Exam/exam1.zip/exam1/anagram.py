def anagaram(s1,s2):
	s1 = s1.lower()
	s2 = s2.lower()
	d1 = {}
	for i in s1:
		if i!=" ":
			if i in d1:
				d1[i]+=1
			else:
				d1[i] =1
	d2={}
	for j in s2:
		if j!=" ":
			if j in d2:
				d2[j]+=1
			else:
				d2[j]=1
	# print(d1, d2)
	if(d1==d2):
		 print(True)
	else:
		print(False)
anagaram('anagram', 'nagaram')
anagaram(' Keep', 'Peek')
anagaram('Mother In Law', 'Hitler Woman')
anagaram('School Master', 'The Classroom') 
anagaram('ASTRONOMERS', 'NO MORE STARS')
anagaram('Toss', 'shot')
anagaram('joy', 'enjoy')
anagaram('Debit Card', 'Bad Credit')
anagaram('SiLeNt CAT', 'LisTen AcT')
anagaram('Dormitory', 'Dirty Room')


