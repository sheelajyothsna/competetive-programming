def RoomKeys(list):
	d = {}
	for i in range(len(list)):
		if i==0:
			d[i] = 1
		else:
			d[i] = 0
	j = 0
	for l in list:
		if d[j]!= 1:
			return False
		for i in range(len(l)):
			if d[i]!= 1:
				return False
			d[l[i]] = 1
		j= j + 1
	return True

print(RoomKeys([[1], [0,2], [3]]))
print(RoomKeys( [[1,3], [3,0,1], [2], [0]]))
print(RoomKeys([[1,2,3], [0], [0], [0]]))
print(RoomKeys([[1], [0,2,4], [1,3,4], [2], [1,2]]))
print(RoomKeys([[1], [2,3], [1,2], [4], [1], [5]]))
print(RoomKeys([[1], [2], [3], [4], [2]] ))
print(RoomKeys([[1], [1,3], [2], [2,4,6], [], [1,2,3], [1]]))





