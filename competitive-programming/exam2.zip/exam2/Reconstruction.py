def reconstructQueue(people):
    people.sort(key=lambda h:[-h[0]])
    result = []
    # print(people)
    for i in people:
        result.insert(i[1], i)
    return result
print(reconstructQueue([[7,0], [4,4], [7,1], [5,0], [6,1], [5,2]]))
print(reconstructQueue([[12,0],[6,3],[3,4],[9,2], [11,1],[1,5]]))
print(reconstructQueue([ [2,4], [5,1], [3,3], [1,5], [4,2], [6,0]]))