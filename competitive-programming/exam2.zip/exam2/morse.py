def uniqueMorse(words):
        morse = [".-", "-...", "-.-.", "-..", ".", "..-.", "--.",
                 "....", "..", ".---", "-.-", ".-..", "--", "-.",
                 "---", ".--.", "--.-", ".-.", "...", "-", "..-",
                 "...-", ".--", "-..-", "-.--", "--.."]
        hai = []
        for word in words:
            s1 = ""
            for c in word:
                s1 = s1 + morse[ord(c) - ord('a')]
            if s1 not in hai:
                hai.append(s1)
        return len(hai) 
print("1 = ",uniqueMorse(["gin", "zen", "gig", "msg"]))
print("2 = ",uniqueMorse(["a", "z", "g", "m"]))
print("3 = ",uniqueMorse(["bhi", "vsv", "sgh", "vbi"]))
print("4 = ",uniqueMorse(["a", "b", "c", "d"]))
print("5 = ",uniqueMorse(["hig", "sip", "pot"]))

